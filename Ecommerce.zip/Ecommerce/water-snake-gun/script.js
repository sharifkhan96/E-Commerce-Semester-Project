 function start(){
  
  let user = prompt("Enter S, W or G")
let cpuI = Math.floor(Math.random() * 3);
let cpu = ["S", "W", "G"][cpuI]

const match = (cpu, user)=>{
  if(cpu === user){
    return "Nobody"
  }
  else if(cpu === "S" && user==="W"){
    return "cpu"
  }
  else if(cpu === "S" && user==="G"){
    return "user"
  }
  else if(cpu === "G" && user==="W"){
    return "user"
  }
  else if(cpu === "G" && user==="S"){
    return "cpu"
  }
  else if(cpu === "W" && user==="S"){
    return "user"
  }
  else if(cpu === "W" && user==="G"){
    return "cpu"
  }
}

var result = match(cpu, user)
//  document.write(`CPU:${cpu} <br> User:${user} <br>The winner is: ${result}`)

  if(result === "user"){
  result = result.concat("🏆")
  }else if(result === "cpu"){
  result = result.concat("🧐")
  }

  document.getElementById("h5one").innerHTML = `CPU: ${cpu}`
  document.getElementById("h5two").innerHTML = `USER: ${user}`
  document.getElementById("h5three").innerHTML = `The winner is ${result}`
  document.getElementById("h5three").innerHTML = `The winner is ${result}`

}



console.log(match(cpu, user))

// document.write(result)
