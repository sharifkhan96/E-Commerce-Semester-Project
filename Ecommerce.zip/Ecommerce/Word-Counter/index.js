

   let textarea = document.querySelector('#tArea');

   textarea.addEventListener('input', function(){

      let charL = this.value.length;
      // console.log(charL);
      document.querySelector('#charS').innerHTML = charL;

      let words = this.value.split(" ");
      // console.log(words);
      let cleanWords = words.filter(function(element){
         return element != "";
      });
      document.querySelector('#wrds').innerText = cleanWords.length;
   });