

//ABCDEFGHIJKLMNOPQRSTUVWXYZ
//abcdefghijklmnopqrstuvwxyz
//0123456789
//!@#$%^&*()_?<>

   function getPassword()
   {
      let chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_?<>.';
      let passLength = 8;
      let password = '';
      for(let i=0; i<passLength; i++)
      {
         let randNum = Math.floor(Math.random() * chars.length);
         // console.log(randNum);
         password += chars.substring(randNum, randNum+1);
         // console.log(password);
      }

      document.querySelector('#password').value = password;
   }