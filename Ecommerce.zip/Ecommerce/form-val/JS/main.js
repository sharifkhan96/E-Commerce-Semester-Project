

   let form = document.getElementById('form');
   let uName = document.getElementById('Myname');
   let emaiL = document.getElementById('email');
   let tazkira = document.getElementById('tazkira');
   let tArea = document.getElementById('description');
   let password = document.getElementById('password');
   let cpassword = document.getElementById('cpassword');
   let img = document.getElementById('image');

   form.addEventListener("submit", (e)=>{
      e.preventDefault();   

      // console.log(validated());
      if(validated())
      {
         alert("Form Successfully Submitted.");
      }
   });

   let validated = ()=>
   {
      let howMuchErrors = [];  //counting errors for true of false returning of validated funtion
      //error funcion
      let error = (element, message)=>
      {
         let groupForm = element.parentElement; // we just intent to ad error class
         groupForm.className = "form-group error"; // we just intent to ad error class
         groupForm.querySelector('small').innerText = message;
         // console.log(groupForm);
         // console.log(element);
      }

      //success funtion
      let success = (element)=>
      {
         let groupForm = element.parentElement;
         groupForm.className = "form-group success";
      }

      //name field validation
      if(uName.value === "")
      {
         error(uName, "Name field is required!");
         howMuchErrors.push(1);
      }else if(uName.value.length < 3)
      {
         error(uName, "Name must be atleast 3 characters!");
         howMuchErrors.push(1);
      }else if(uName.value.match(/[0-9]/g)) //regex using
      {
         error(uName, "Names can only be strings!");
         howMuchErrors.push(1);
      }else
      {
         success(uName);
      }

      //email field validation 
      if(emaiL.value === "")
      {
         error(emaiL, "Email field is required!");
         howMuchErrors.push(1);
      }else if(!emaiL.value.includes("@"))
      {
         error(emaiL, "Invalid Email Address");
         howMuchErrors.push(1);
      }else if(emaiL.value.length < 5)
      {
         error(emaiL, "Email must be at least 5 characters");
         howMuchErrors.push(1);
      }else
      {
         success(emaiL);
      }
      
      //tazkira field validation 
      if(tazkira.value === "")
      {
         error(tazkira, "Tazkira field is required!");
         howMuchErrors.push(1);
      }else if(tazkira.value.match(/[a-zA-Z]/g))
      {
         error(tazkira, "Tazkira No must only be numbers");
         howMuchErrors.push(1);
      }else if(tazkira.value.length <6)
      {
         error(tazkira, "Tazkra No should at least be 6 digits!");
         howMuchErrors.push(1);
      }else
      {
         success(tazkira);
      }

      //description field validation 
      if(tArea.value === "")
      {
         error(tArea, "Description field is required!");
         howMuchErrors.push(1);
      }else if(tArea.value.length < 2)
      {
         error(tArea, "What??");
         howMuchErrors.push(1);
      }else
      {
         success(tArea);
      }

      //password field validation 
      if(password.value === "")
      {
         error(password, "Password field is required!");
         howMuchErrors.push(1);
      }else if(password.value.length < 8)
      {
         error(password, "Password must at least 8 character!");
         howMuchErrors.push(1);
      }else
      {
         success(password);
      }
      
      //cpassword field validation 
      if(cpassword.value === "")
      {
         error(cpassword, "Confirm password field is required!");
         howMuchErrors.push(1);
      }else if(password.value != cpassword.value)
      {
         error(cpassword, "Password didn't match!");
         howMuchErrors.push(1);
      }else
      {
         success(cpassword);
      }

      //img field validation
      if(img.value === "")
      {
         error(img, "Image field is required!");
         howMuchErrors.push(1);
      }else
      {
         success(img);
      }

      if(howMuchErrors.length > 0)
      {
         return false;
      }else
      {
         return true;
      } 

   }

   

